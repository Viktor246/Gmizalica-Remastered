<?php
	$servername = '127.0.0.1';
	$dbusername = 'root';
	$dbpass = 'root';
	$dbname = 'gmizalica';
?>